# 20. Pruebas y Aseguramiento de Calidad (QA)

No asumas que un sistema funciona solo porque su código compila o "se ve bonito" en el navegador.

## Análisis de Cobertura

- **Pruebas de Componentes Frontend:** `PARCIAL`. Se evidencia un diseño fuertemente basado en componentes desacoplados, pero la cobertura de librerías como Jest / React Testing Library requiere expansión para evitar que un botón deje de funcionar tras actualizaciones futuras de dependencias.
- **Pruebas de Lógica de Backend (Unitarias):** `PARCIAL`. Aunque existe la carpeta de tests con los andamiajes nativos de NestJS (`*.spec.ts`), es necesario programar validadores críticos. 
- **Riesgo:** Confiar ciegamente en pruebas manuales consumirá excesivo tiempo del Director de Operaciones cada vez que VITAHUB lance una actualización (Regression Testing humano).

## Plan de QA Sugerido (Corto Plazo)
Implementar automatización con **Cypress** o **Playwright**.
Programar un "robot" que, antes de cada despliegue, inicie sesión automáticamente, intente vulnerar un endpoint con un usuario falso y simule crear una pieza para garantizar que las reglas 6.1 (UD) y 6.2 (XP) funcionan perfectamente bajo presión.
