# 08. Diccionario de Datos

Este diccionario extrae los campos críticos funcionales de las entidades reales encontradas en el código base, especificando su origen y sensibilidad.

## Entidad: `users`
| Campo | Tipo | Origen | Sensibilidad | Validación |
| :--- | :--- | :--- | :--- | :--- |
| `id` | UUID | Sistema | Pública (Interna) | Clave Primaria |
| `email` | String | Ingreso Manual | Alta (PII) | Formato Email Obligatorio |
| `role` | Enum | Asignación Admin | Crítica | `ADMIN`, `DIRECTOR`, `CM`, `DESIGNER`, `CLIENT` |
| `organization_id` | UUID | Sistema | Muy Alta | Aislamiento Tenant (Obligatorio) |

## Entidad: `leads`
| Campo | Tipo | Origen | Sensibilidad | Validación |
| :--- | :--- | :--- | :--- | :--- |
| `id` | UUID | Sistema | Pública (Interna) | Clave Primaria |
| `source` | Enum | Meta / Manual | Baja | `META_ADS`, `MANUAL`, `REFERRAL` |
| `status` | Enum | Manual | Media | `NEW`, `CONTACTED`, `NEGOTIATION`, `WON`, `LOST` |
| `contact_info` | JSONB | Ingreso / Webhook | Alta (PII) | Objeto con phone/email. Encriptable para CAPI. |

## Entidad: `pieces` (Piezas de Diseño)
| Campo | Tipo | Origen | Sensibilidad | Validación |
| :--- | :--- | :--- | :--- | :--- |
| `status` | Enum | Flujo UI | Media | `BACKLOG`, `IN_PROGRESS`, `REVIEW`, `CLIENT_VALIDATION`, `APPROVED` |
| `ud_cost` | Decimal | Cálculo Sistema | Media (Facturación) | Basado en matriz de precios |
| `corrections_count` | Integer | Sistema | Media | Max 3 (regla de negocio), incrementable manual. |
| `file_url` | String | Integración Drive | Media | Debe cumplir Regex de Nomenclatura |

## Entidad: `xp_records` (Gamificación)
| Campo | Tipo | Origen | Sensibilidad | Validación |
| :--- | :--- | :--- | :--- | :--- |
| `designer_id` | UUID | Relacional | Baja | FK a Users |
| `points` | Integer | Cálculo Cron | Baja | Positivos o Negativos |
| `reason` | String | Sistema | Baja | Ej: "Bono velocidad", "Penalización atraso" |

*(Nota: Los campos no críticos de timestamps como `created_at` o `updated_at` existen globalmente en todas las tablas por herencia de TypeORM).*
