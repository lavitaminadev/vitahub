# 26. Pendientes (Roadmap de Ejecución)

Consolidado extraído rigurosamente del contraste entre la aspiración operativa y el código verificado.

### 1. ALTA PRIORIDAD (Siguientes Semanas - "Ensangrentar el Sistema")
- **Paso a Producción de CRM Base:** Desplegar en servidor final y conectar la App de Meta con permisos mínimos para que los comerciales dejen los excels y se suban a la plataforma mañana mismo.

### 2. CORTO PLAZO (Construcción Operativa)
- **UI de Producción (UD) y Gamificación:** El backend está operando, falta la vista de administrador de piezas para que "María Ignacia" reste UDs al cliente y la pantalla para que "Roy / Emily" revisen los XP ganados por entregar antes del tiempo.
- **Portal del Cliente:** Crear el panel externo protegido por clave para que los clientes hagan login a aprobar piezas, en lugar de usar WhatsApp.

### 3. MEDIANO PLAZO (La Conexión Externa)
- **Bandeja Unificada de Mensajes:** Esperar validación del engorroso "App Review" de Meta (con videos de prueba estrictos). Al ser aprobado, conectar los Sockets de chat en la UI del CRM.
- **Integración de Facturador Local:** Seleccionar si se conectará a "Toku" (Pagos recurrentes) o a un facturador directo como "Nubox" mediante APIs para emitir alertas.
