# 04. Arquitectura Actual

VITAHUB sigue un modelo arquitectónico de **Sistemas Distribuidos pero centralizados en un Monorepo**. Esto significa que todo el código fuente vive en un mismo lugar para facilitar el mantenimiento, pero las responsabilidades están físicamente y lógicamente separadas.

## 1. Patrón Arquitectónico Backend (NestJS)

El backend de VITAHUB no es un sistema espagueti. Utiliza una arquitectura basada en **Módulos, Controladores y Casos de Uso (Services)** fuertemente influenciada por principios de "Arquitectura Limpia" (Clean Architecture).

- **Core Module (`apps/api/src/core`):** Contiene interceptores, protección de rutas, manejo global de errores (Exception Filters) y autenticación.
- **Feature Modules (`apps/api/src/modules/*`):** Agrupa dominios de negocio específicos. Por ejemplo, `crm/`, `integrations/meta/`, `production/`. Cada uno es dueño de su base de datos.
- **Jobs y Cron (`apps/api/src/core/jobs`):** Subsistema asíncrono que corre tareas en segundo plano (como recuperación de leads caídos) sin bloquear las peticiones de los usuarios web.

## 2. Patrón Arquitectónico Frontend (React + Vite)

El frontend (`apps/web`) está diseñado bajo el patrón **SPA (Single Page Application)**.
- Se comunica de forma exclusiva mediante API REST (JSON) contra el Backend.
- Se utiliza `React Query` (`@tanstack/react-query`) para manejar la caché, las peticiones asíncronas y las mutaciones. Esto es crucial porque hace que la plataforma sea "Reactiva" (si el servidor responde que un lead cambió de estado, la UI se actualiza sola sin recargar).
- **Agnóstico de Framework CSS Pesado:** Utiliza CSS Vanilla estructurado (`index.css`) para evitar dependencias tóxicas a largo plazo o vendor lock-in con librerías de interfaz gráfica, otorgando el 100% del control del diseño a La Vitamina.

## 3. Capa de Persistencia (Base de Datos)

Se utiliza una base de datos relacional (MySQL/PostgreSQL) orquestada por **TypeORM**.
La arquitectura de datos de VITAHUB está fuertemente acoplada a un diseño **Multi-Tenant (Múltiples inquilinos)**. Cada registro en las tablas críticas tiene una columna `organization_id`. 
Esto asegura que la plataforma es escalable y que, si el día de mañana La Vitamina decide arrendar este software a otras agencias, los datos nunca se mezclarán por accidente.

## 4. Comunicación Externa (Event-Driven)
Para las integraciones con Meta, la arquitectura usa "Webhooks" (conexiones bidireccionales).
Además, utiliza el módulo `EventEmitter2` interno de NestJS. Cuando un evento ocurre (Ej: `lead.converted`), no se detiene la ejecución del usuario esperando que Facebook responda; el evento se lanza al aire, un "Handler" lo atrapa y lo procesa asíncronamente en el fondo, mejorando el rendimiento para quien navega la web.
