# 37. Trazabilidad contra Documento Maestro

Fecha de emision: `2026-07-16`

## 1. Fuente auditada

Documento base recibido:

- `La Vitamina - Documento Maestro de Operaciones`
- version declarada en el archivo: `0.2`
- caracter: especificacion funcional, no evidencia de implementacion

Este documento es importante porque aclara que:

- define el alcance funcional deseado;
- separa proceso humano de funcionalidad de sistema;
- deja varias decisiones marcadas como `[DEFINIR]`;
- declara explicitamente que no debe inventarse logica donde direccion aun no cerro la regla.

## 2. Lo que cambia al leer el Maestro

La auditoria previa ya habia detectado sobreafirmaciones. Con el Maestro en mano, esa conclusion se fortalece y se vuelve mas precisa:

1. Muchas brechas del codigo no son "errores de implementacion", sino decisiones que el propio Maestro deja abiertas.
2. Varias cosas que parecian "faltantes" son en realidad puntos de extension razonables mientras la direccion no defina la regla exacta.
3. El valor del repositorio no debe medirse solo contra "producto terminado", sino contra "alineacion responsable al Maestro sin inventar reglas".

## 3. Alineaciones fuertes Maestro -> Codigo

### 3.1 Arquitectura central

El Maestro dice:

- reemplazar Trello y Google Sheets;
- producir tablero nativo;
- portal cliente propio;
- integracion con Drive;
- integracion con Meta y otros proveedores.

En el repo se observa:

- modulos propios de CRM, produccion, UDs, XP, reuniones, onboarding, catalogo, documentos, aprobaciones e integraciones;
- frontend con rutas y vistas internas reales;
- base para portal cliente;
- integracion Meta avanzada;
- integracion Drive solo parcial.

Lectura correcta:

- la direccion del producto si esta reflejada en el codigo;
- el cierre funcional es desigual por modulo.

### 3.2 Roles y permisos

El Maestro define:

- director comercial;
- creatividad;
- operaciones;
- arte;
- audiovisual;
- IA;
- community manager;
- diseno;
- cliente.

En el repo se observa:

- enum y tipos de usuario consistentes con buena parte de esos roles;
- guardias de autenticacion y roles;
- manifests frontend con restricciones por ruta.

Lectura correcta:

- hay alineacion real de roles;
- todavia falta revisar mas fino el scoping por cuenta o pod, que el Maestro deja parcialmente abierto.

### 3.3 Modelo de datos central

El Maestro enumera entidades como:

- lead;
- cliente;
- contrato/plan;
- brief;
- ciclo mensual;
- grilla;
- pieza;
- moodboard;
- sesion;
- reunion/acta;
- reporte;
- presupuesto UD;
- XP;
- factura/pago;
- catalogo.

En el repo se observan entidades reales para una parte grande de ese mapa.

Lectura correcta:

- el repositorio no improviso una estructura ajena al Maestro;
- el modelado central si siguio el documento de origen.

### 3.4 Reglas de negocio fuertes

El Maestro fija como nucleo:

- flujo de pipeline comercial;
- flujo de produccion;
- regla de tres correcciones;
- matriz UD;
- sistema XP;
- validacion de aprobaciones;
- notificaciones de piezas estancadas.

En el repo se observan:

- conversion transaccional lead -> cliente;
- workflow de produccion;
- `correctionCount`;
- `ud-budget`;
- calculadora XP;
- solicitudes de aprobacion;
- job de stale pieces.

Lectura correcta:

- la implementacion si absorbio varias reglas clave del Maestro;
- algunas siguen incompletas en UI, automatizacion o facturacion asociada.

## 4. Partes del Maestro que siguen abiertas y por eso no debian "inventarse"

Estas no deben contarse automaticamente como fallas del desarrollador ni del repositorio, porque el propio Maestro las deja abiertas:

- esquema definitivo del brief;
- produccion audiovisual final;
- regla exacta de UD excedidas;
- visibilidad de saldo UD para cliente;
- metricas definitivas de CM y AV;
- proveedor de facturacion;
- modelo definitivo de pods;
- precios comerciales definitivos;
- reglas finales de reels adicionales;
- detalles finales de aprobacion del cliente.

Esto coincide con:

- `docs/decisions/pending-business-decisions.md`

## 5. Donde el informe anterior necesitaba matiz a la luz del Maestro

### 5.1 Portal cliente

El Maestro lo pone como pieza central.

Concluson correcta:

- si el portal no estuviera nada mas que planeado, seria una brecha critica;
- como hoy existe base de rutas y piezas de portal, la brecha sigue siendo importante, pero no de cero absoluto.

### 5.2 Audiovisual

El Maestro mismo dice que audiovisual estaba en propuesta aparte y subespecificado.

Concluson correcta:

- no corresponde medir audiovisual con el mismo rigor de "requisito cerrado" que CRM o pipeline;
- si corresponde documentarlo como modulo con definicion parcial.

### 5.3 Drive

El Maestro habla de integracion con Drive como repositorio.

Concluson correcta:

- el sistema hoy refleja esa intencion en entidades, campos y referencias;
- pero no debe afirmarse que la integracion esta terminada mientras `syncToDrive()` siga pendiente.

### 5.4 Reportería

El Maestro declara la reporteria como el dato mas importante del sistema.

Concluson correcta:

- si hay endpoints y vistas, eso muestra alineacion conceptual;
- pero la reporteria final del Maestro depende de integraciones externas aun no cerradas.

## 6. Lo que el Maestro confirma sobre la auditoria hecha

El Maestro valida varias decisiones de la auditoria:

- que no se deben inventar reglas donde haya `[DEFINIR]`;
- que una pantalla no equivale a funcionalidad terminada;
- que la trazabilidad y los permisos son parte estructural del sistema;
- que Meta, CRM, produccion, UDs, XP, portal y reporteria son el corazon del alcance;
- que el orden correcto es arquitectura base -> integraciones -> flujos verticales -> modulos operativos.

## 7. Conclusion util para leer el paquete

Con el Maestro como fuente, la lectura mas justa del repo y de la auditoria es esta:

- el repositorio si esta orientado al sistema correcto;
- varias reglas clave del Maestro si llegaron a codigo real;
- no todo lo faltante debe leerse como incumplimiento, porque parte del alcance sigue abierto por direccion;
- aun asi, no corresponde presentar el sistema como cerrado mientras existan fallas de build, integraciones parciales y modulos todavia incompletos.

## 8. Referencias relacionadas

- [35. Auditoria de Veracidad Exhaustiva](./35-AUDITORIA-DE-VERACIDAD-EXHAUSTIVA.md)
- [36. Anexos y Vacios No Adjuntados](./36-ANEXOS-Y-VACIOS-NO-ADJUNTADOS.md)
- `docs/gap-analysis-vs-maestro.md`
- `docs/maestro-alignment-2026-07-16.md`
- `docs/decisions/pending-business-decisions.md`
