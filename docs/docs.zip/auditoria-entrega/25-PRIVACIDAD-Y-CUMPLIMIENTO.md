# 25. Privacidad y Cumplimiento

Estado verificado al `2026-07-16`.

## Controles encontrados

- Exportacion de datos propios de usuario.
- Anonimizacion de usuario.
- Exportacion de datos de lead por organizacion.
- Anonimizacion de lead por organizacion.
- Registro de consentimientos.

## Evidencia de codigo

- `apps/api/src/core/data-protection/data-protection.controller.ts`
- `apps/api/src/core/data-protection/data-protection.service.ts`

## Lo que si puede afirmarse

- Existe una base tecnica para atender solicitudes de exportacion y anonimizado.
- El lead anonimizado conserva el registro operativo, pero nulifica o reemplaza campos personales relevantes.

## Lo que no debe afirmarse

- No corresponde asegurar cumplimiento legal total solo por estas funciones.
- No corresponde afirmar que la empresa queda "100% libre de multas".
- No corresponde afirmar que toda PII este cifrada en reposo; lo probado en codigo es cifrado de secretos de integracion, no de todas las tablas de negocio.

## Diagnostico

El proyecto muestra una intencion seria de privacidad y gobierno de datos, pero el cumplimiento integral depende tambien de:

- bases legales y consentimientos operativos;
- politica de retencion;
- controles de acceso en despliegue;
- HTTPS real en produccion;
- backups;
- trazabilidad y procedimientos internos.
