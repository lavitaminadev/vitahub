# 14. Auditoría de Integraciones y APIs Externas

Este documento audita exhaustivamente cómo VITAHUB se conecta con servicios de terceros, con foco especial en la infraestructura de Meta (Facebook/Instagram), detallando los mecanismos de seguridad, dificultades operativas y regulaciones chilenas asociadas.

## 1. Integración Meta: Lead Ads (Prospectos)
**Estado:** `IMPLEMENTADA Y OPERATIVA`

### Arquitectura de Comunicación (Webhooks)
La recepción de "Leads" funciona bajo un esquema *Event-Driven* empujado por Meta hacia VITAHUB.

- **GET `/api/webhooks/meta` (Verificación de Suscripción):**
  Para que Meta empiece a enviar datos, exige validar que el servidor nos pertenece. Cuando se configura la "App" en el portal de desarrolladores, Meta envía una solicitud HTTP `GET` con un parámetro `hub.challenge` y un `hub.verify_token`. 
  *Evidencia:* En `meta.controller.ts`, el sistema compara el token recibido con la variable de entorno `META_WEBHOOK_VERIFY_TOKEN`. Si coincide, responde con el `challenge`, sellando el pacto de comunicación.

- **POST `/api/webhooks/meta` (Recepción de Datos en Tiempo Real):**
  Cada vez que un cliente llena un formulario en un anuncio de La Vitamina, Meta envía un `POST` al instante.
  *Seguridad implementada:* Meta firma digitalmente el payload enviando el header `x-hub-signature-256`. El backend de VITAHUB (`MetaService.verify`) recalcula el hash SHA-256 usando el `META_APP_SECRET` local. Si las firmas no coinciden, la petición es rechazada con un Error 403 (Forbidden), evitando que atacantes inyecten Leads falsos.

### Dificultades y Retos Operativos ("El dolor de integrar Meta")
Conectar Meta nunca es una simple conexión de API; requiere lidiar con políticas burocráticas severas.
1. **Pérdida de Leads por Caídas de Red:** Si VITAHUB sufre una desconexión o lentitud de más de 20 segundos, Meta marca el webhook como fallido. Meta intenta reenviar, pero tras varios fallos, desactiva la suscripción.
   *Solución aplicada:* Se construyó `MetaLeadRecoveryJob` (Cron cada 4 horas) que consulta activamente la Graph API de Meta (`GET /:form_id/leads`) por prospectos generados recientemente, reconciliando e insertando a la base de datos a aquellos que nunca llegaron por el Webhook.
2. **Access Tokens de Corta Duración:** Los tokens de Facebook expiran. El sistema `MetaOAuthService` implementa el intercambio de "Short-Lived Tokens" por "Long-Lived Tokens" (duración de 60 días), pero de igual manera exige que el administrador vuelva a reconectar la cuenta periódicamente antes de su vencimiento, o el Job de recuperación fallará.

## 2. Integración Meta: Conversions API (CAPI)
**Estado:** `IMPLEMENTADA SIN VERIFICACIÓN EN PRODUCCIÓN`

- **POST hacia Graph API (`/events`):** 
  El `LeadConvertedHandler` reacciona cuando un ejecutivo en el CRM de VITAHUB marca una oportunidad como "Ganada" y la pasa a la tabla `Clients`. Se despacha un evento `Purchase` Server-to-Server.
  *Manejo de Datos Personales:* En cumplimiento de las reglas del píxel avanzado, antes de mandar la petición, VITAHUB encripta el teléfono (`ph`) y correo (`em`) del cliente con la función criptográfica `SHA-256`. Meta nunca recibe el correo en texto plano, solo el Hash, que compara contra su base de usuarios gigantesca para atribuir la publicidad.

## 3. Integración Meta: Data Deletion Callback (GDPR / Ley Chile)
**Estado:** `IMPLEMENTADA Y OPERATIVA`

- **POST `/api/webhooks/meta/data-deletion`:**
  Si un usuario va a su cuenta de Facebook y revoca el acceso a VITAHUB, la ley (y las políticas de Meta) exigen que exista una URL donde el usuario pueda solicitar el borrado de sus datos. 
  VITAHUB procesa esta solicitud (`parseMetaSignedRequest`), purga las credenciales OAuth asociadas en la tabla `integration_accounts` y entrega un `confirmation_code` alfanumérico al usuario para demostrar que sus datos de acceso fueron borrados.

### Impacto Legal (Ley N° 19.628 - Protección de la Vida Privada en Chile)
Aunque la infraestructura está diseñada según el GDPR europeo (que es más estricto que la ley chilena actual), La Vitamina cuenta con total blindaje tecnológico para la inminente modernización de la Ley de Datos Personales en Chile (boletín 11144-07).
1. El sistema anonimiza Leads en base de datos (`AnonymizeLeadUseCase`) reemplazando nombres e IPs con asteriscos, respetando el "Derecho al Olvido".
2. Toda interacción se traza (Trazabilidad) bajo el usuario que la realizó (Audit logs).

## 4. Próxima Integración: Bandeja Unificada de Mensajería (Instagram / Messenger)
**Estado:** `PLANIFICADO (A espera de App Review)`

Para materializar el Chat unificado:
- Se requiere que el Webhook actual procese también los campos `messages` y `messaging_postbacks`.
- El sistema necesitará implementar `WebSockets` (Socket.io) para enviar la información del servidor hacia el frontend del ejecutivo en milisegundos, permitiéndole responder DMs sin refrescar la página.
- **Riesgo asociado:** Meta restringe enormemente el envío de mensajes por fuera de una "ventana de 24 horas". La lógica en VITAHUB deberá bloquear el campo de texto ("Disabled") si la fecha de última interacción (`updated_at`) supera los 86,400 segundos.
