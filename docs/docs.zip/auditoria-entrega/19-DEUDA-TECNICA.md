# 19. Auditoría de Deuda Técnica

La deuda técnica representa el "código rápido" que se escribe hoy para salir del paso, pero que requerirá refactorización mañana o causará problemas a escala. VITAHUB tiene un nivel **BAJO** de deuda técnica destructiva, pero existen focos de atención.

## Inventario de Deuda Clasificada

| Problema | Clasificación | Motivo y Riesgo | Recomendación Inmediata |
| :--- | :--- | :--- | :--- |
| **Pruebas Automatizadas Incompletas** | `ALTA` | Las pruebas unitarias/E2E son parciales. Si el sistema escala y otro desarrollador edita el código de conversión de prospectos, podría romper algo crítico (Ej: enviar leads vacíos) sin darse cuenta. | Crear una "Suite de Pruebas Unitarias" estricta antes de abrir a nuevos clientes SaaS. |
| **Audiovisual Subespecificado** | `MEDIA` | El área Audiovisual no tiene el mismo rigor matemático (Puntajes, UDs) que la Producción Gráfica. | Directivo y líder de área deben acordar parámetros lógicos de negocio. |
| **Falta de Trazabilidad Total (Auditoría BD)** | `MEDIA` | Los cambios de estado no mantienen un log estricto de historial (quien hizo qué el martes a las 4pm). | Implementar TypeORM Subscribers para llenar tablas temporales de auditoría para "Logs de Actividad" en los perfiles de Lead/Cliente. |
| **Módulos con Mock Data** | `COSMÉTICA` | En ciertas páginas de reportería visual se identificaron gráficos estáticos (datos simulados o "dummies"). | Estas vistas no deben habilitarse hasta integrarse el módulo de Reportes. |
