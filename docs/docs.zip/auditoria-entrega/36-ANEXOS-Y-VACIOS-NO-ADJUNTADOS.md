# 36. Anexos y Vacios No Adjuntados

Fecha de emision: `2026-07-16`

## Proposito

Este anexo documenta lo que faltaba en el paquete `docs/auditoria-entrega` original o lo que estaba insuficientemente cubierto para una lectura exhaustiva del repositorio real.

No reemplaza al informe principal. Lo complementa con huecos detectados durante la segunda pasada de auditoria.

## 1. Material faltante o poco cubierto

### 1.1 Modulo Uploads

Faltaba documentar con claridad:

- existe `UploadsController` y `UploadsService`;
- el almacenamiento operativo actual es local en disco;
- `driveFileId` existe a nivel de modelo;
- la sincronizacion real a Google Drive no esta terminada.

Evidencia:

- `apps/api/src/modules/uploads/uploads.controller.ts`
- `apps/api/src/modules/uploads/uploads.service.ts`
- `apps/api/src/modules/uploads/upload.entity.ts`

Impacto documental:

- el paquete original tendia a sugerir que los archivos pesados ya descansaban en Drive;
- la realidad es almacenamiento local con preparacion parcial para Drive.

### 1.2 Modulo Notifications

Faltaba documentar:

- backend de notificaciones con listado, contador y marcado como leido;
- UI visible limitada a `NotificationBell`, no a una pagina completa.

Evidencia:

- `apps/api/src/core/notifications/notifications.controller.ts`
- `apps/api/src/core/notifications/notification.service.ts`
- `apps/web/src/features/notifications/NotificationBell.tsx`

Impacto documental:

- el modulo existe y es util, pero su expresion frontend es acotada.

### 1.3 Modulo Audiovisual

Faltaba adjuntar:

- CRUD de `moodboards`;
- CRUD de `sessions`;
- protecciones por rol;
- alcance operativo del modulo.

Evidencia:

- `apps/api/src/modules/audiovisual/audiovisual.controller.ts`
- `apps/api/src/modules/audiovisual/audiovisual.service.ts`
- `apps/api/src/modules/audiovisual/audiovisual.module.ts`

Impacto documental:

- el paquete estaba muy centrado en CRM, Meta y produccion grafica;
- audiovisual existe como modulo propio y debia quedar reflejado.

### 1.4 Modulo Knowledge / RAG

Faltaba documentar:

- endpoints de `knowledge`;
- existencia de `semanticSearch`;
- limitacion clave: el `KnowledgeStore` actual es en memoria.

Evidencia:

- `apps/api/src/modules/knowledge/knowledge.controller.ts`
- `apps/api/src/modules/knowledge/rag.service.ts`
- `apps/api/src/modules/knowledge/knowledge.store.ts`

Impacto documental:

- el modulo existe y no es menor;
- pero no debe presentarse como base de conocimiento persistente o enterprise-grade sin matiz.

### 1.5 Client Scope del portal

Faltaba adjuntar:

- el mecanismo transversal para restringir recursos al `clientId` del usuario cliente.

Evidencia:

- `apps/api/src/core/client-scope/client-scope.interceptor.ts`
- `apps/api/src/core/client-scope/client-scope.decorator.ts`

Impacto documental:

- el informe hablaba de portal cliente, pero no explicaba esta capa tecnica.

### 1.6 Health y observabilidad administrativa

Faltaba documentar:

- endpoints `/health`, `/health/db`, `/health/integrations`;
- endpoint `/metrics` restringido a admin;
- chequeos de memoria, disco, DB y Redis.

Evidencia:

- `apps/api/src/core/health/health.controller.ts`
- `apps/api/src/core/health/health.service.ts`
- `apps/api/src/core/health/integrations-health.service.ts`
- `apps/api/src/core/observability/metrics.controller.ts`

Impacto documental:

- `17-OBSERVABILIDAD.md` estaba demasiado enfocado en recomendaciones;
- faltaba describir lo que ya existe.

## 2. Material tecnico no adjuntado como evidencia dura

### 2.1 Resultado de validaciones ejecutadas

El paquete original no adjuntaba de forma clara el estado de validacion actual:

- `npm run test:api` -> OK
- `npm run lint:web` -> OK con warnings
- `npm run lint:api` -> FAIL
- `npm run build:api` -> FAIL
- `npm run build:web` -> FAIL

Impacto documental:

- sin esto, varios documentos se leian como mas concluyentes de lo que permitia el estado real del workspace.

### 2.2 Brecha entre pruebas y build

Tambien faltaba explicitar una tension importante:

- la API tiene buena senal de calidad por pruebas;
- pero el estado de integracion actual sigue roto a nivel de compilacion.

Esto debia aparecer como hallazgo estructural, no solo como detalle tecnico.

## 3. Secciones del informe que quedaron cortas

### 3.1 Observabilidad

`17-OBSERVABILIDAD.md` no documenta suficientemente:

- `metrics`;
- health checks ya implementados;
- distincion entre logging basico actual y monitoreo real faltante.

### 3.2 QA

`20-PRUEBAS-Y-QA.md` quedo desactualizado frente a la evidencia ejecutada.

Le faltaba consignar:

- que el backend si tiene suites reales;
- cantidad de tests ejecutados y aprobados;
- que el problema actual mas fuerte no es ausencia total de testing, sino desacople entre tests y build.

### 3.3 Integraciones de archivos

El paquete no separaba bien:

- referencias a Drive en documentos, aprobaciones y versiones;
- vs subida local real de archivos;
- vs sincronizacion Drive todavia no implementada.

## 4. Recomendacion documental

Para que el paquete quede realmente exhaustivo en una siguiente iteracion, conviene actualizar o ampliar estos documentos:

1. `17-OBSERVABILIDAD.md`
2. `20-PRUEBAS-Y-QA.md`
3. `21-RENDIMIENTO.md`
4. `23-COSTOS-Y-DEPENDENCIAS.md`
5. `30-MANUAL-TECNICO.md`

## 5. Conclusion

Lo que faltaba no era solo "mas texto". Faltaba capturar partes reales del sistema que ya existen en codigo y, al mismo tiempo, explicitar mejor varias limitaciones:

- uploads reales pero locales;
- notifications reales pero con UI acotada;
- audiovisual y knowledge presentes pero subdocumentados;
- client scope y health checks poco visibles;
- pruebas reales conviviendo con builds fallidos.

Este anexo queda agregado para cerrar ese vacio.
