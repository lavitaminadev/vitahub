# 29. Matriz de Evidencias

Estado verificado al `2026-07-16`.

| Afirmacion | Evidencia real | Observacion |
| :--- | :--- | :--- |
| Cifrado de secretos de integracion | `apps/api/src/shared/security/integration-secrets.ts` | Implementa AES-256-GCM para secretos de integracion. |
| Webhook Meta verificado | `apps/api/src/modules/integrations/meta/meta.controller.ts` | Incluye verificacion de firma y endpoints publicos para Meta. |
| Descarga y normalizacion de leads Meta | `apps/api/src/modules/integrations/meta/meta-lead-ads.service.ts` | El servicio consulta Graph API y normaliza campos del lead. |
| Conversion transaccional de lead a cliente | `apps/api/src/modules/crm/leads/use-cases/convert-lead.use-case.ts` | Usa `transaction()` y emite `lead.converted`. |
| Handler de conversion hacia Meta CAPI | `apps/api/src/modules/integrations/meta/handlers/lead-converted.handler.ts` | Existe, pero hoy no compila por un enum faltante. |
| Tenancy base | `apps/api/src/core/tenancy/tenant.middleware.ts` y `tenant.guard.ts` | Resuelven y validan `organizationId`. |
| Portal y rutas protegidas | `apps/web/src/core/ProtectedRoute.tsx` y `ClientRoute.tsx` | Hay guardas para usuarios autenticados y portal cliente. |
| Jobs de negocio | `apps/api/src/core/jobs/jobs.module.ts` y `apps/api/src/core/jobs/cron/*.ts` | Existe la logica de jobs; falta validar ejecucion automatica real. |
| Estado de pruebas API | `apps/api/test/**` y ejecucion `npm run test:api` | Paso el `2026-07-16` con `97` tests. |
| Estado de build | `npm run build:api` y `npm run build:web` | Ambos fallan al `2026-07-16`. |
