# 06. Decisiones Técnicas y Valor Empresarial

Esta sección audita las decisiones de ingeniería estructurales tomadas en la construcción de VITAHUB. Para cada decisión clave, se evalúa su impacto en el negocio (La Vitamina), los riesgos que previene y las ventajas competitivas que otorga.

---

### DECISIÓN 1: Transacciones ACID en la Base de Datos

- **EL PROBLEMA:** En sistemas de concurrencia, si dos ejecutivos intentan convertir un mismo prospecto a la vez, o si el servidor falla en el milisegundo exacto en que se convierte el Lead pero antes de crear el Cliente, la base de datos queda corrupta e inoperable (datos huérfanos).
- **QUÉ SE ELIGIÓ:** Utilizar `EntityManager.transaction()` de TypeORM para agrupar todas las consultas críticas en un solo bloque.
- **BENEFICIO PARA LA VITAMINA:** Consistencia de datos absoluta de grado bancario. Si algo falla a medio camino, se aplica un "rollback" (marcha atrás) total automático.
- **COSTO FUTURO EVITADO:** Incontables horas de ingenieros teniendo que corregir a mano la base de datos y buscando dónde se perdió la información financiera.

---

### DECISIÓN 2: Desacoplamiento Event-Driven para Meta CAPI

- **EL PROBLEMA:** Cuando la API de Meta está lenta, si el Backend espera a que Facebook responda antes de avisarle al usuario, el ejecutivo comercial experimentaría un "congelamiento" de la plataforma de varios segundos al clickear.
- **QUÉ SE ELIGIÓ:** Arquitectura manejada por eventos (`EventEmitter2`).
- **BENEFICIO PARA LA VITAMINA:** El ejecutivo comercial percibe una plataforma increíblemente rápida. El backend le responde inmediatamente de forma local, mientras procesa el envío de la señal a Estados Unidos en un segundo plano.

---

### DECISIÓN 3: Hashing Nativo SHA-256 en Conversions API

- **EL PROBLEMA:** Enviar datos de clientes (Emails, Teléfonos) en texto plano hacia agencias de publicidad externa viola normativas modernas de privacidad (GDPR / Legislación local chilena).
- **QUÉ SE ELIGIÓ:** Encriptación SHA-256 en el payload antes de despachar el evento `Purchase`.
- **RIESGO EVITADO:** Evita cuantiosas multas por exposición de PII (Personally Identifiable Information) o bloqueos de la cuenta publicitaria (Ad Account) por parte de Meta.

---

### DECISIÓN 4: Diseño Vanilla CSS en vez de Tailwind (Frontend)

- **EL PROBLEMA:** Los frameworks de utilidad como Tailwind a menudo dejan el código (HTML) plagado de cientos de clases, dificultando auditorías de accesibilidad o forzando a los desarrolladores a depender de compiladores complejos.
- **QUÉ SE ELIGIÓ:** CSS puro y fuertemente tipado (`index.css`) con variables estandarizadas (`--primary`, `--bg-white`, etc.).
- **DIFICULTAD PARA MIGRAR / VENDOR LOCK-IN:** Cero. VITAHUB no le debe "lealtad" a un framework de diseño. Mañana La Vitamina puede cambiar toda su imagen de marca simplemente reemplazando 5 variables de color en la primera línea del archivo, sin tener que tocar la lógica en los cientos de componentes React.
