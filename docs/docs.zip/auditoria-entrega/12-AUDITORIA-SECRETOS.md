# 12. Auditoría de Secretos y Credenciales

Esta fase de la auditoría garantiza que los tokens financieros y de acceso a plataformas corporativas (Meta, Google, Base de Datos) no estén expuestos ni comprometidos.

## Hallazgos Forenses

| Objeto Sensible | Ubicación Común | Estado de Auditoría | Evidencia / Mecanismo |
| :--- | :--- | :--- | :--- |
| **Variables de Entorno** | `.env` | `SEGURO` | El archivo está explícitamente ignorado en `.gitignore`. Solo existe un archivo `.env.example` en el repositorio, el cual contiene valores vacíos `your_secret_here`. |
| **Tokens Meta OAuth** | Base de Datos (`integration_accounts`) | `SEGURO` | Almacenados mediante encriptación Simétrica. Se requiere la "llave maestra" del servidor para desencriptar el string y enviarlo a CAPI o a la Graph API. |
| **Secretos JWT** | Código Fuente | `SEGURO` | El módulo de autenticación no usa strings duros en el código, extrae el valor `JWT_SECRET` del entorno de ejecución al inicializarse. |
| **Credenciales DB** | `app.module.ts` | `SEGURO` | La conexión TypeORM utiliza variables inyectadas (`process.env.DB_PASSWORD`), protegiendo el acceso a la MySQL/PostgreSQL subyacente. |

### Recomendación de Continuidad
Se debe establecer un proceso de "Rotación de Secretos" cada 6 meses, especialmente para el App Secret de Meta. El sistema está preparado para soportarlo simplemente cambiando la variable de entorno y reiniciando los contenedores de Docker, sin necesidad de reprogramar.
