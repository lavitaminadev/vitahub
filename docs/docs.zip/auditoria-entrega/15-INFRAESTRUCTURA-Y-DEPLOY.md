# 15. Infraestructura y Deploy

Estado verificado al `2026-07-16`.

## Lo que si existe en el repositorio

- Monorepo con `npm` workspaces.
- Docker Compose para `mysql`, `redis`, `api` y `web`.
- Dockerfiles para API y Web en `infrastructure/deployment/`.
- Workflow CI en `.github/workflows/ci.yml`.
- Scripts de despliegue y soporte en `infrastructure/`.

## Lo que no debe afirmarse sin matiz

- No hay evidencia de `turborepo`.
- No hay evidencia de que el despliegue actual este probado de punta a punta.
- No corresponde decir que produccion esta "lista" solo por existir Dockerfiles y scripts.

## Diagnostico honesto

- **Desarrollo local:** bien encaminado, con estructura clara y automatizaciones basicas.
- **Deploy tecnico:** preparado a nivel de artefactos y configuracion.
- **Operatividad real de produccion:** no demostrada completamente, porque al `2026-07-16` `build:api` y `build:web` fallan.

## Implicaciones

La arquitectura permite desplegar:

- frontend como sitio estatico;
- backend como servicio Node persistente;
- base de datos MySQL;
- Redis como dependencia de soporte.

Pero antes de presentar esto como plataforma lista para nube se debe corregir:

1. compilacion backend;
2. compilacion frontend;
3. estrategia real de jobs;
4. validacion del procedimiento de despliegue.
