# 30. Manual Técnico de Mantenimiento

Para cualquier Ingeniero o Desarrollador futuro que retome VITAHUB:

## Instalación y Arranque (Local)
1. El proyecto es un monorepo (usualmente gestionado vía `pnpm` o `yarn`).
2. Clonar el repositorio.
3. Ejecutar `pnpm install` en la raíz.
4. Crear archivo `.env` basado en `.env.example`.
5. Levantar base de datos local (MySQL/PostgreSQL) vía Docker.
6. Correr `pnpm dev` para levantar de forma concurrente el servidor API (puerto típico 3000) y el servidor React (Vite, puerto 5173).

## Reglas Inquebrantables de Código
1. **Nada va a DB sin Tenancy:** Está estrictamente prohibido usar el repositorio global (Ej: `this.leadsRepository.find()`) si la ruta está protegida. Siempre inyectar el `organization_id` o usar los Scope Managers para evitar cruzar información de agencias.
2. **Webhooks Públicos, pero Validados:** Cualquier controlador nuevo bajo `webhooks/` debe usar `@Public()` y `@SkipTenancy()`, pero está forzado a implementar verificación criptográfica nativa (SHA-256 Hmac) en sus headers antes de tocar la DB.
3. **No alterar `.gitignore`:** `.env` NUNCA debe subirse a Git.

## Cómo Agregar Integraciones (Meta y otros)
1. Se debe respetar el patrón del módulo `integrations/`.
2. Las clases de servicio no se mezclan. (Ej: `meta.service` hace la comunicación, `meta-oauth.service` gestiona la autenticación, `meta-lead-ads.service` procesa el contenido funcional).
