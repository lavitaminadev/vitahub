# 28. Matriz de Riesgos y Protecciones

Análisis de riesgos operativos corporativos y cómo la arquitectura los mitiga.

| Riesgo / Amenaza | Nivel Base | Mitigación Arquitectónica Implementada | Riesgo Residual Actual |
| :--- | :--- | :--- | :--- |
| **Robo de Cartera de Clientes** | Alto | Sistema de JWT + Roles. Los usuarios rol 'Designer' no tienen acceso de red a descargar el listado de todos los clientes de la agencia. | **Bajo** |
| **Colapso API Externa (Meta)** | Alto | Desacoplamiento por Eventos. VITAHUB guarda localmente y empuja a Meta en segundo plano. Si Meta cae, VITAHUB sigue vivo. | **Bajo** |
| **Facturación Duplicada / Corrupción Concurrente** | Crítico | Transacciones de Base de datos atómicas (`EntityManager.transaction()`). | **Cero** |
| **Bloqueo App Review Meta (Bandeja DMs)** | Crítico | Postergar la función de Bandeja Unificada hasta que el CRM base esté en producción. No construir sin antes estar aprobados. | **Medio** |
| **Pérdida Crítica de Archivos Gráficos** | Crítico | VITAHUB **no** guarda los archivos `.psd` o `.ai` en su base de datos, sino que enruta hipervínculos a **Google Drive**. El riesgo descansa en Google. | **Bajo** |
