# 05. Diagramas de Arquitectura

Para ayudar a la comprensión de los flujos de datos auditados, aquí se representan las arquitecturas reales del sistema mediante diagramas Mermaid.

### Diagrama de Contexto (Context Diagram)

Representa el panorama a "10,000 pies de altura", demostrando quién interactúa con VITAHUB y cómo se relaciona con agentes externos.

```mermaid
graph TD
    %% Usuarios
    User_Comercial["🧑‍💼 Equipo Comercial\n(La Vitamina)"]
    User_Diseno["🎨 Equipo Producción\n(La Vitamina)"]
    User_Cliente["🏢 Clientes Externos"]
    
    %% Sistema Central
    VITAHUB{"💻 Plataforma VITAHUB\n(Monorepo: React + NestJS)"}
    
    %% Componentes Externos
    Meta_Graph_API["🌐 Meta Graph API\n(Lead Ads, Webhooks)"]
    Meta_CAPI["🎯 Meta Conversions API\n(Optimizador de Ads)"]
    Base_Datos[("🗄️ Base de Datos\nRelacional")]
    
    %% Relaciones
    User_Comercial -- "Gestiona Leads / Contratos" --> VITAHUB
    User_Diseno -- "Visualiza Piezas / Sube Diseños" --> VITAHUB
    User_Cliente -- "Aprueba Piezas / Ve Reportes" --> VITAHUB
    
    VITAHUB -- "Lee / Escribe / Bloqueos ACID" --> Base_Datos
    VITAHUB -- "Recibe prospectos en T. Real" <-- "Envía payloads" --> Meta_Graph_API
    VITAHUB -- "Notifica Clientes Ganados" --> Meta_CAPI
```

### Diagrama de Flujo Event-Driven (CAPI & CRM)

El siguiente diagrama detalla la interacción interna cuando un prospecto se transforma en una venta, demostrando cómo opera el aislamiento asíncrono para mejorar el rendimiento.

```mermaid
sequenceDiagram
    participant Ejecutivo as 🧑‍💼 Ejecutivo Comercial
    participant CRM_UI as 🖥️ VITAHUB Frontend
    participant Nest_API as ⚙️ VITAHUB Backend (API)
    participant DB as 🗄️ Database
    participant Emitter as 📡 Internal Event Emitter
    participant CAPI as 🎯 Meta Conversions API

    Ejecutivo->>CRM_UI: Clic en "Convertir a Cliente"
    CRM_UI->>Nest_API: POST /crm/leads/{id}/convert
    
    Note over Nest_API,DB: Inicio de Transacción Segura (ACID)
    Nest_API->>DB: Bloqueo de fila Lead
    Nest_API->>DB: Inserta registro en tabla Clients
    Nest_API->>DB: Actualiza estado Lead a WON
    Nest_API-->>DB: Commit Transacción
    
    Nest_API->>Emitter: Emite 'lead.converted'
    Nest_API-->>CRM_UI: Respuesta HTTP 200 OK (Rápida)
    CRM_UI-->>Ejecutivo: Muestra éxito en UI instantáneamente
    
    %% Proceso asíncrono en background
    Emitter->>Nest_API: Trigger LeadConvertedHandler
    Nest_API->>Nest_API: Busca Pixel Token Desencriptado
    Nest_API->>Nest_API: Aplica SHA-256 a Email/Teléfono
    Nest_API->>CAPI: POST Evento 'Purchase' (Hasheado)
```

### Arquitectura de Recuperación y Tolerancia a Fallos

Cómo evita VITAHUB perder prospectos si los servidores fallan o Meta no los envía.

```mermaid
graph LR
    Cron["⏱️ Cron Job\n(Cada 4 Horas)"]
    Job["⚙️ MetaLeadRecoveryJob"]
    Meta["🌐 Meta API"]
    DB[("🗄️ Database")]
    Logica["🔍 Lógica de Deduplicación\n(syncSingleLead)"]

    Cron -- "Gatilla" --> Job
    Job -- "Pregunta por últimos leads" --> Meta
    Meta -- "Retorna lista de Leads recientes" --> Job
    Job -- "Envía leads al procesador" --> Logica
    Logica -- "¿Ya existe el Lead_ID en BD?" --> DB
    DB -- "Sí" --> Logica
    Logica -- "Ignora" --> Job
    DB -- "No" --> Logica
    Logica -- "Inserta nuevo Lead" --> DB
```
