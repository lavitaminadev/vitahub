# 34. Especificacion de APIs

Estado verificado al `2026-07-16`.

Este documento enumera endpoints y flujos con evidencia directa en el codigo. Cuando un comportamiento no pudo probarse de punta a punta, se marca como parcial.

## 1. Endpoints Meta verificados

### `GET /api/webhooks/meta`

- Verificacion de suscripcion de Meta.
- Requiere coincidencia de `hub.verify_token` con `META_WEBHOOK_VERIFY_TOKEN`.
- Evidencia: `apps/api/src/modules/integrations/meta/meta.controller.ts`.

### `POST /api/webhooks/meta`

- Recibe el webhook de Meta.
- Verifica firma `x-hub-signature-256`.
- Normaliza y despacha mensajes.
- Procesa leads mediante `MetaLeadAdsService`.
- Evidencia: `meta.controller.ts` y `meta-lead-ads.service.ts`.

### `POST /api/webhooks/meta/data-deletion`

- Procesa `signed_request`.
- Devuelve `confirmation_code` y URL de estado.
- Evidencia: `meta.controller.ts`.

### `GET /api/webhooks/meta/data-deletion/status`

- Devuelve estado del `confirmation_code`.
- Evidencia: `meta.controller.ts`.

## 2. Endpoints internos relevantes verificados

### `GET /api/crm/leads`

- Lista leads del CRM.
- Evidencia: `apps/api/src/modules/crm/leads/lead.controller.ts`.

### `PUT /api/crm/leads/:id`

- Actualiza estado y atributos operativos del lead.
- Evidencia: `lead.controller.ts`.

### `POST /api/crm/leads/:id/convert`

- Convierte un lead a cliente usando transaccion.
- Emite evento `lead.converted`.
- Evidencia: `lead.controller.ts` y `convert-lead.use-case.ts`.

### `GET /api/data-protection/leads/:id/export`

- Exporta datos de lead por organizacion.
- Evidencia: `apps/api/src/core/data-protection/data-protection.controller.ts`.

### `DELETE /api/data-protection/leads/:id/anonymize`

- Anonimiza un lead por organizacion.
- Evidencia: `data-protection.controller.ts` y `data-protection.service.ts`.

## 3. Flujos parciales o con cautela

### Meta CAPI

- Existe handler de `lead.converted`.
- Existe envio server-to-server.
- Estado actual: `PARCIAL`, porque el handler presenta una inconsistencia de enum que hoy rompe compilacion.

### Recovery de leads

- Existe `MetaLeadRecoveryJob`.
- Estado actual: `PARCIAL`, porque la ejecucion automatica del job no quedo demostrada en esta auditoria.

## 4. Nota importante

Esta especificacion no debe leerse como contrato productivo definitivo mientras `build:api` y `build:web` sigan fallando. Sirve como mapa del API implementado y de sus principales cautelas actuales.
