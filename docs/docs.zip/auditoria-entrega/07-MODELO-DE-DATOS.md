# 07. Arquitectura Lógica y Modelo de Datos (Verificado)

A continuación, se detalla el análisis forense de las entidades que conforman el motor de base de datos relacional de VITAHUB y cómo sustentan el *Documento Maestro de Operaciones* de La Vitamina.

## Entidades Principales Encontradas

### 1. Entidades del Eje Corporativo
- **`Organization`**: Representa a la agencia ("La Vitamina"). Es la dueña de la instancia.
- **`User`**: Miembros de la agencia (Nicolás, Nathaly, Diseñadores, CM). Almacena el campo `role` que determina la jerarquía.
- **`Pod`**: Grupos fijos de trabajo. Los clientes se asignan a Pods para organizar la distribución de CMs y creativos de forma escalar.

### 2. Entidades del Eje Comercial (CRM)
- **`Lead`**: Entidad de prospecto. Incluye atributos críticos como `status` (Nuevo, Contactado, Negociación, etc.), `source` (Ej: Meta Ads), `contact_info` y `organization_id` para el aislamiento multi-tenant.
- **`Client`**: Al realizarse la transición exitosa de un Lead ("Ganado"), el sistema muta la entidad hacia Cliente. Contiene la vinculación al Pod asignado.
- **`Plan` / `Contract`**: Define el retainer. Estipula la cuota de **UD (Unidades de Diseño)** que el cliente tiene derecho a consumir mensualmente.

### 3. Entidades del Eje Operativo (Producción)
- **`UDBudget`**: Registro matemático mensual por cliente. Registra el Total Contratado vs el Saldo Consumido. *Al no ser acumulable*, su estado expira por ciclo.
- **`Piece`**: La unidad atómica de diseño. Contiene `type` (Post, Carrusel), `status` (Backlog, En Progreso, Aprobación), y vinculaciones críticas como `assignee_id` (el Diseñador) y el `ud_cost` que descontará a la agencia.

### 4. Entidades del Eje Humano (Gamificación)
- **`XpRecord` / `XpEvent`**: Log inmutable que registra cada punto de experiencia ganado o perdido por los diseñadores de La Vitamina. Guarda el motivo (`bonus_speed`, `penalty_correction`), y el timestamp para evaluar los Rankings semanales.

## Análisis de Consistencia Referencial
Se validó la existencia de claves foráneas restrictivas (Foreign Keys con cascadas en `DELETE`). Esto implica que si Nicolás borra accidentalmente una "Organización" en la base de datos maestra, todas las piezas, leads y archivos asociados se eliminarán o bloquearán estructuralmente de forma inmediata, evitando tener datos "huérfanos" o inconsistentes flotando en la memoria del servidor.
