# 31. Manual de Despliegue (Producción)

Guía rápida para la puesta en marcha inicial del servidor en un entorno "Vivo".

1. **Adquirir Servidor Dedicado (VPS o PaaS)**
   Dado los Cron Jobs de NestJS, contratar "Render Web Service", "Railway", "Heroku" o un "DigitalOcean Droplet".
2. **Variables de Entorno Críticas en Producción**
   - `DB_HOST`, `DB_PORT`, `DB_USERNAME`, `DB_PASSWORD` (Credenciales de la Base de datos manejada, no la local).
   - `JWT_SECRET` (Una string extremadamente larga y compleja, ej: generada con `openssl rand -hex 32`).
   - `META_APP_SECRET`, `META_WEBHOOK_VERIFY_TOKEN` (Copiadas estrictamente del Panel de Desarrolladores de Facebook > Configuración Básica).
3. **Compilación (Build Phase)**
   - Correr `pnpm build`. Esto compila NestJS a Javascript plano (carpeta `dist/`) y empaqueta React usando Vite.
4. **Subida de Front (Servicio Estático)**
   - La carpeta compilada del frontend se sube a servicios sin costo por mantener el servidor encendido, como Vercel o Cloudflare Pages, conectando al subdominio `app.lavitamina.cl`.
5. **Configuración del Meta Webhook (Portal de FB)**
   - Ir a la configuración de la App de Meta en "Developer Portal".
   - Apuntar la URL base al dominio de backend de producción + `/api/webhooks/meta`.
   - Pegar el mismo string puesto en `META_WEBHOOK_VERIFY_TOKEN`. Facebook hará el ping inmediatamente.
