# 03. Inventario Funcional

A continuación, se detalla el inventario de los módulos detectados en el código fuente de VITAHUB, su estado de implementación y sus características operativas.

### 1. Módulo Core (Autenticación y Tenancy)
- **Objetivo:** Gestionar el acceso, roles, y separar los datos entre múltiples agencias/organizaciones (si en el futuro Vitahub se vuelve SaaS).
- **Tablas:** `users`, `organizations`, `sessions`.
- **Estado Real:** `OPERATIVO`.
- **Auditoría:** La inyección de `organizationId` en todas las consultas críticas asegura que no haya fugas de información inter-empresa.

### 2. Módulo CRM (Comercial)
- **Objetivo:** Seguimiento de prospectos (Leads) y gestión del embudo de ventas.
- **Tablas:** `leads`, `opportunities`, `interactions`.
- **Estado Real:** `OPERATIVO`.
- **Auditoría:** Se utiliza el patrón "Kanban". Implementa "Transacciones ACID" (`ConvertLeadUseCase`) para asegurar consistencia de datos cuando un Lead pasa a ser Cliente.

### 3. Módulo Integraciones Externas
- **Objetivo:** Conexión y sincronización de datos con proveedores (Meta, Google).
- **Tablas:** `integrations`, `integration_accounts`, `meta_lead_webhook_events`.
- **Estado Real:** `OPERATIVO` (Para Meta).
- **Auditoría:** Implementa webhook robusto para recibir Leads de Ads. Incluye manejador asíncrono para enviar conversiones (CAPI) y Jobs de reconciliación (`MetaLeadRecoveryJob`).

### 4. Módulo de Producción (Operaciones)
- **Objetivo:** Gestión de los entregables (Piezas gráficas, campañas) de La Vitamina.
- **Tablas:** `pieces`, `ud_budgets`.
- **Estado Real:** `PARCIAL`.
- **Auditoría:** Existe el job `DetectStalePiecesJob` para alertar piezas estancadas. La lógica de descuento de la matriz presupuestaria (UD) está definida en base de datos, pero la interfaz de arrastre y aprobación cliente requiere pulido visual.

### 5. Módulo de Gamificación
- **Objetivo:** Sistema de recompensas y Puntos de Experiencia (XP) para el equipo de diseño en base a la velocidad y falta de correcciones.
- **Tablas:** `xp_events`, `xp_periods`.
- **Estado Real:** `PARCIAL`.
- **Auditoría:** Los Jobs cron programados (ej. `CloseXpPeriodsJob`) corren adecuadamente calculando las métricas, falta exponer un "Dashboard de Nivel" atractivo para los usuarios internos.

### 6. Módulo de Data Protection (GDPR / Privacidad)
- **Objetivo:** Cumplimiento legal de borrado o exportación de datos PII (Personally Identifiable Information).
- **Endpoints:** `/data-protection/leads/:id/anonymize`
- **Estado Real:** `OPERATIVO`.
- **Auditoría:** Verificable en la interfaz del Cajón Lateral (Side Drawer) del Kanban CRM.

*(El inventario exhaustivo backend vs frontend confirma una alta priorización de la lógica de negocio sólida por encima de interfaces estéticas temporales).*
