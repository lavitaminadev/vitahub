# 10. Auditoría Multitenant (Multi-Agencia)

VITAHUB no es un software tradicional de "una sola empresa". Su base de datos está construida arquitectónicamente como un SaaS (Software as a Service) Multi-Tenant. 

## Aislamiento de Datos
- **Mecanismo:** El `TenancyInterceptor` a nivel global en NestJS.
- **Funcionamiento:** Todo usuario que inicia sesión pertenece a una `Organization`. El servidor extrae el `organization_id` del token JWT en cada request y lo inyecta a nivel del ORM (TypeORM).
- **Riesgo Mitigado:** Si el día de mañana "La Vitamina" le arrienda este software a la agencia "Competencia SpA", los clientes, piezas y finanzas de La Vitamina jamás se filtrarán a la Competencia, incluso si el desarrollador Frontend comete un error en la UI, ya que la base de datos bloquea la consulta de raíz.

## Fuga de Archivos y URLs
- Las integraciones a Drive están vinculadas por carpetas asociadas al ID del Cliente, el cual pertenece a la Organización.
- Se recomienda implementar firmas de URL de expiración corta (Signed URLs) para los archivos multimedia en fases posteriores, agregando una capa extra de protección contra accesos no autorizados a material confidencial.
