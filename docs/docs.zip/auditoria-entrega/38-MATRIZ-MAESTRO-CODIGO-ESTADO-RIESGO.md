# 38. Matriz Maestro -> Codigo -> Estado -> Riesgo

Fecha de emision: `2026-07-16`

## 1. Como leer esta matriz

Esta matriz traduce el Documento Maestro a una hoja de ruta operativa.

Estados usados:

- `IMPLEMENTADO`: existe evidencia directa y usable en codigo.
- `PARCIAL`: existe base funcional, pero falta cierre tecnico, UI, integracion o automatizacion.
- `ABIERTO POR NEGOCIO`: el Maestro deja la regla pendiente y el codigo no debe inventarla.
- `RIESGO TECNICO`: existe funcionalidad o base, pero hoy hay problemas de build, integracion, despliegue o validacion.

## 2. Matriz ejecutiva

| Modulo | Lo que pide el Maestro | Evidencia en codigo | Estado | Riesgo principal | Dependencia abierta | Siguiente accion recomendada |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Plataforma base | Auth, tenancy, audit, jobs, health, observability | `apps/api/src/core/*`, router y guards frontend | `IMPLEMENTADO` | Build backend/frontend fallando reduce confianza operativa | Ninguna funcional | Corregir compilacion y revalidar bloque 0 tecnico |
| CRM / Pipeline comercial | Lead -> contacto -> reunion -> presupuesto -> negociacion -> ganado/perdido | `crm/leads`, `crm/contacts`, `crm/interactions`, `crm/opportunities`, `LeadsPage.tsx` | `PARCIAL` | Flujo existe pero no todo el pipeline comercial esta cerrado de punta a punta | Reglas comerciales finas de presupuesto | Cerrar create/update/convert y enlazar mejor oportunidades/interacciones |
| Onboarding | Cliente ganado -> brief -> checklist -> activacion | `modules/onboarding`, `modules/briefs`, `features/onboarding`, `features/briefs` | `PARCIAL` | El flujo existe pero no toda la maquina de estados ni brief definitivo | Esquema definitivo del brief | Mantener CRUD y checklist, no endurecer formulario final sin decision |
| Catalogo comercial | Servicios, precios, planes, presupuestos | `modules/catalog`, `features/catalog` | `PARCIAL` | Base lista pero falta poblar reglas comerciales definitivas | Precios, planes y reels finales | Usar el modulo como catalogo configurable mientras direccion cierra valores |
| Produccion grafica | Tablero, estados, versionado, validacion, correcciones | `modules/production`, `ProductionPage.tsx`, naming validator, approvals | `PARCIAL` | Flujo backend fuerte, experiencia visual y cierre cliente aun incompletos | Regla exacta de cobro por cuarta correccion | Completar acciones faltantes y alinear UI al flujo oficial del Maestro |
| Presupuesto UD | Matriz de consumo, saldo mensual, no acumulable, reglas de exceso | `design-budget`, `ud-budget`, `ud-movement` | `PARCIAL` | Tracking existe pero faltan decisiones de exceso y visibilidad final | Bloqueo/aviso/cobro por exceso, visibilidad cliente | Mantener tracking y registrar decision pendiente en UI y contratos |
| Gamificacion XP | XP semanal, bonos, penalizaciones, ranking | `gamification`, `xp-calculator`, jobs, ranking backend | `PARCIAL` | Backend fuerte pero sin experiencia frontend madura y scheduler no probado | Metricas definitivas para CM y AV | Corregir ejecucion real de jobs y agregar vistas operativas |
| Audiovisual | Moodboards, sesiones, flujo AV, propuesta separada | `modules/audiovisual` | `PARCIAL` | El modulo existe, pero la definicion de negocio aun no esta cerrada | Niveles AV, tiempos, XP y flujo final | Tratarlo como modulo en preparacion, no como flujo cerrado |
| Grilla / Contenido | Calendario mensual por cuenta | `modules/content`, `ContentGridPage.tsx` | `PARCIAL` | Hay base de contenido, falta una experiencia de calendario mas completa | Criterios finales de operacion por cuenta | Completar CRUD visual y relacion con ciclo mensual |
| Aprobaciones | Flujo interno + cliente aprueba/rechaza | `modules/approvals`, `ApprovalsPage.tsx`, portal cliente | `PARCIAL` | Existe base real pero faltan reglas UX y detalle de validacion final | Pieza vs grilla, tiempos tacitos | Consolidar el flujo de cliente con comentarios y evidencia de pieza |
| Portal cliente | Grilla, actas, reportes, aprobaciones | `features/client-portal/*`, `ClientRoute.tsx`, endpoints client-aware | `PARCIAL` | Existe base, pero no cubre aun toda la promesa central del Maestro | Visibilidad UD y detalle de aprobacion | Priorizar este modulo como brecha de negocio visible |
| Reuniones y actas | Reunion mensual + seguimiento + acta | `modules/meetings`, `MeetingsPage.tsx` | `PARCIAL` | CRUD existe, falta plantillado y experiencia cliente completa | Estructura obligatoria de reunion | Definir plantilla y acceso cliente segun proceso real |
| Reporteria de resultados | Metricas de venta generada, integraciones Meta/Google/reservas/CRM | `modules/reports`, `DirectionPage.tsx`, `ReportsPage.tsx` | `PARCIAL` | La intencion existe, pero el cierre del dato mas importante aun depende de integraciones externas | Plataformas de reserva y CRM externo definitivos | Enfocar el roadmap de reporteria por fuentes priorizadas |
| Facturacion y pagos | Facturas, mora, cobranzas, integracion proveedor | `modules/billing`, `features/billing` | `PARCIAL` | Entidad y UI base existen, pero no hay integracion externa final | Proveedor de facturacion y politica de cobranza | Cerrar primero proveedor y secuencia de correos antes de automatizar |
| Gestion documental | Drive, nomenclatura, carpetas, enlaces | `modules/documents`, `modules/uploads`, `features/documents` | `PARCIAL` | El sistema hoy usa base documental y subida local; Drive real no esta cerrado | Implementacion final de Drive y estructura de carpetas | No vender Drive como terminado mientras `syncToDrive()` siga pendiente |
| Notificaciones y alertas | Piezas estancadas, reuniones, UD, facturas, reportes | `core/notifications`, `NotificationBell.tsx`, jobs | `PARCIAL` | Existe base, pero el motor transversal aun no cubre todo el Maestro | Reglas finales de alertas por modulo | Completar cobertura por caso de negocio y mejorar entrega UI |
| Usuarios y permisos | Roles por rol y por cuenta/pod | `modules/users`, auth, roles, manifests, client-scope | `PARCIAL` | Roles existen, pero el scoping por cuenta/pod no esta completo | Modelo final de pods | Endurecer permisos por cuenta cuando direccion cierre el modelo |
| Dashboards por rol | Directivo, operaciones, CM, diseno, cliente | `dashboard`, `direction`, varias pages internas | `PARCIAL` | Hay dashboards reales, pero no todos los roles tienen vista dedicada madura | Metrica final por rol | Priorizar cliente, diseno y CM |
| Integracion Meta | OAuth, activos, webhooks, leads, pixel, CAPI | `modules/integrations/meta/*`, `integrations` frontend | `RIESGO TECNICO` | Flujo avanzado pero hoy con rotura de compilacion y jobs no demostrados | App Review y estados administrativos externos | Corregir build y revalidar flujo end-to-end |
| Integracion Google / Drive | OAuth y activos asociados | `modules/integrations/google/*`, referencias Drive | `PARCIAL` | OAuth base existe, Drive operativo aun no | Modelo final de uso con documentos/uploads | Separar claramente Google OAuth de Drive operativo |
| Salud y observabilidad | Health, metrics, logs, trazabilidad | `core/health`, `core/observability`, `core/audit` | `PARCIAL` | Ya existe base util, pero no observabilidad productiva completa | Estrategia final de monitoreo externo | Completar logging estructurado y monitoreo en despliegue |

## 3. Riesgos transversales que cambian la lectura de toda la matriz

| Riesgo transversal | Efecto sobre modulos | Severidad | Accion |
| :--- | :--- | :--- | :--- |
| `build:api` falla | Reduce confianza en integracion backend | `ALTA` | Corregir antes de declarar modulo operativo |
| `build:web` falla | Reduce confianza en experiencia usable real | `ALTA` | Corregir imports/tsc y volver a validar |
| Jobs no demostrados en scheduler real | Afecta XP, UD, alertas y recovery Meta | `ALTA` | Definir estrategia unica de ejecucion |
| Integraciones externas sin cierre administrativo | Afecta Meta, reporteria y facturacion | `MEDIA/ALTA` | Separar dependencia tecnica de dependencia de negocio/terceros |
| Decisiones `[DEFINIR]` del Maestro | Afecta brief, AV, UD, facturacion, portal | `MEDIA` | Mantener puntos de extension y no inventar reglas |

## 4. Priorizacion recomendada

### Prioridad 1: saneamiento tecnico

1. Corregir `build:api`.
2. Corregir `build:web`.
3. Revalidar jobs y cron reales.
4. Reprobar integracion Meta end-to-end.

### Prioridad 2: brechas visibles para negocio

1. Portal cliente.
2. Produccion visual y aprobaciones.
3. Reporteria util para cliente/direccion.
4. Facturacion y cobranza con proveedor real definido.

### Prioridad 3: decisiones de direccion que desbloquean cierre

1. Brief definitivo.
2. Regla de exceso UD.
3. Alcance audiovisual final.
4. Proveedor de facturacion.
5. Metricas finales de CM y AV.

## 5. Conclusion

La mejor lectura operativa del proyecto no es "terminado" ni "vacío".

Es esta:

- hay una base claramente alineada al Documento Maestro;
- varios modulos ya tienen evidencia real en codigo;
- el cierre final depende tanto de saneamiento tecnico como de decisiones de negocio que el propio Maestro mantiene abiertas;
- por eso la hoja de ruta correcta debe separar muy bien lo que es deuda tecnica de lo que es definicion pendiente de direccion.
