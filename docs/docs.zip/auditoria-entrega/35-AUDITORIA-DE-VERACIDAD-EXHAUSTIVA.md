# 35. Auditoria de Veracidad Exhaustiva

Fecha de auditoria: `2026-07-16`

## 1. Alcance y metodologia

Esta revision contrasta el contenido de `docs/auditoria-entrega` contra el estado real del repositorio.

Fuentes auditadas:

- `package.json`, `README.md`, `.env.example`
- `apps/api/src/**`
- `apps/web/src/**`
- `apps/api/test/**`
- `infrastructure/**`
- `.github/workflows/ci.yml`

Validaciones ejecutadas:

- `npm run test:api` -> OK
- `npm run lint:web` -> OK con warnings
- `npm run lint:api` -> FAIL
- `npm run build:api` -> FAIL
- `npm run build:web` -> FAIL

## 2. Dictamen ejecutivo

El paquete documental original no es falso en bloque, pero mezcla tres niveles distintos sin separarlos bien:

1. hechos comprobados en codigo;
2. inferencias razonables sobre intencion de producto;
3. afirmaciones demasiado fuertes sobre operacion real, despliegue o mitigacion de riesgos.

La conclusion correcta al `2026-07-16` es esta:

- El repositorio muestra una base funcional amplia, con backend NestJS, frontend React y multiples dominios de negocio implementados.
- El CRM de leads, autenticacion, multitenancy base, proteccion de datos, integraciones Meta y varias pantallas internas tienen evidencia real en codigo.
- Existen jobs, integraciones y flujos de negocio importantes, pero no todos estan conectados de forma demostrablemente operativa.
- La plataforma no esta en estado "terminado y solido" ni "lista para alto trafico" si se exige que compile y haga build hoy: el backend y el frontend presentan errores de compilacion.

## 3. Hallazgos de alta importancia

### 3.1 El API pasa pruebas, pero no compila

Evidencia:

- `npm run test:api` paso con `24` archivos y `97` tests.
- `npm run lint:api` y `npm run build:api` fallan.

Errores observados:

- `apps/api/src/core/jobs/cron/meta-lead-recovery.job.ts` usa imports con rutas incorrectas.
- `apps/api/src/modules/integrations/meta/handlers/lead-converted.handler.ts` referencia `IntegrationAccountType.PIXEL`, pero el enum actual no tiene `PIXEL`.

Implicacion:

- El backend tiene buena cobertura puntual en varias areas, pero su estado de integracion actual no permite afirmar "produccion lista" ni "operativo total".

### 3.2 El frontend tampoco builda en su estado actual

Evidencia:

- `npm run build:web` falla.

Errores observados:

- `apps/web/src/features/crm/components/LeadDetailDrawer.tsx` tiene imports relativos incorrectos.
- `apps/web/src/features/crm/LeadsPage.tsx` mantiene variables sin uso que hoy no rompen `oxlint`, pero si aparecen en `tsc`.

Implicacion:

- Hay UI real y no trivial, pero el estado actual del workspace sigue siendo de desarrollo activo.

### 3.3 Los jobs existen, pero su ejecucion automatica no esta demostrada de forma completa

Hechos confirmados:

- Existen clases `CloseXpPeriodsJob`, `CreateMonthlyCyclesJob`, `DetectStalePiecesJob`, `CollectionEmailsJob`, `PurgeExpiredLeadsJob` y `MetaLeadRecoveryJob`.
- Estan registradas en `apps/api/src/core/jobs/jobs.module.ts`.

Limites detectados:

- No se encontro `ScheduleModule`, `@Cron`, `@Interval` ni otro scheduler en Nest.
- `infrastructure/cron/crontab` existe, pero referencia archivos como `dist/cron/close-xp-period.js`.
- Dado el `tsconfig` actual, el arbol compilado esperable seria bajo `dist/core/jobs/cron/...`, no `dist/cron/...`.

Implicacion:

- Es correcto decir "existe logica de jobs".
- No es correcto afirmar sin matices que "los cron jobs corren adecuadamente" o que la mitigacion ya esta operando en produccion.

### 3.4 La integracion Meta existe, pero su cierre de punta a punta tiene riesgos concretos

Hechos confirmados:

- Webhook Meta publico en `apps/api/src/modules/integrations/meta/meta.controller.ts`.
- Verificacion HMAC del webhook.
- Descarga de detalle del lead via Graph API en `meta-lead-ads.service.ts`.
- Evento `lead.converted` emitido en `convert-lead.use-case.ts`.

Riesgos reales:

- El handler de conversion a CAPI no builda por el enum `PIXEL` faltante.
- El recovery job existe, pero su ejecucion automatica no esta demostrada.

Implicacion:

- La narrativa correcta es "integracion Meta avanzada pero con brechas de integracion y despliegue", no "blindaje total".

### 3.5 Google Drive esta modelado, pero no implementado como sincronizacion real

Evidencia:

- `apps/api/src/modules/uploads/uploads.service.ts` contiene `syncToDrive()` con `TODO`.
- Existen campos `driveFileId` en entidades y DTOs.

Implicacion:

- Se puede hablar de preparacion para Drive y de referencias a archivos externos.
- No se debe afirmar que el almacenamiento operativo ya descansa en Google Drive.

## 4. Estado real verificado del sistema

## 4.1 Plataforma y stack

- Monorepo npm workspaces.
- Backend: NestJS 11 + TypeORM + MySQL.
- Frontend: React 19 + Vite 8 + React Router + React Query.
- Paquete compartido: `packages/shared`.

Correccion importante:

- La documentacion historica habla en algunos puntos de NestJS 10, PostgreSQL, `pnpm`, `yarn` o `turborepo`.
- El repositorio real hoy usa `npm` workspaces y configuracion de TypeORM para MySQL.

## 4.2 Backend

Confirmado en codigo:

- Autenticacion JWT.
- Roles y guardias.
- Tenancy por `organizationId`.
- Modulos de negocio amplios: CRM, clientes, contratos, catalogo, produccion, presupuestos UD, gamificacion, reuniones, contenido, documentos, onboarding, reportes, integraciones, usuarios y otros.

Matiz:

- La existencia de modulos no equivale a completitud funcional uniforme.

## 4.3 Frontend

Confirmado en codigo:

- Router con rutas protegidas y portal cliente.
- Pantallas para CRM, produccion, clientes, aprobaciones, reuniones, reportes, integraciones, usuarios, catalogo, documentos y mas.
- Kanban de leads y drawer de detalle presentes en el codigo.

Matiz:

- La UI existe y tiene trabajo real, pero no debe venderse como cerrada mientras el build falla.

## 4.4 Datos y base de datos

Confirmado en codigo:

- Hay entidades TypeORM y migraciones versionadas.
- Se observa una estrategia consistente de `organizationId` en buena parte del modelo.

Matiz:

- "Cada modulo es dueno de su base de datos" es incorrecto. El sistema usa una base relacional compartida por modulos.

## 4.5 Seguridad y secretos

Confirmado:

- JWT guard.
- Roles guard.
- Helmet.
- ValidationPipe global.
- Throttling.
- Cifrado AES-GCM de secretos de integracion en `apps/api/src/shared/security/integration-secrets.ts`.

Matiz:

- Esto demuestra controles importantes, pero no basta para declarar cumplimiento legal total ni riesgo residual cero.

## 4.6 Proteccion de datos

Confirmado:

- Exportacion y anonimizado de datos de usuario.
- Exportacion y anonimizado de leads por organizacion.

Matiz:

- La anonimizacion de leads reemplaza o nulifica varios campos, pero no es prueba suficiente de cumplimiento normativo integral por si sola.
- No corresponde afirmar que la empresa queda "100% libre de multas legales".

## 4.7 Calidad y pruebas

Confirmado:

- Existen tests unitarios, de integracion y e2e para varias areas.
- La API paso `97` tests.

Limitacion:

- El hecho de que pasen tests no compensa los errores de compilacion actuales.

## 5. Veracidad archivo por archivo

| Archivo | Veredicto | Observacion principal | Accion tomada |
| :--- | :--- | :--- | :--- |
| `00-INDICE-MAESTRO.md` | `INCORRECTO/PARCIAL` | Presentaba el paquete como cerrado y algunos bloques como pendientes pese a existir archivos. | Corregido. |
| `01-RESUMEN-EJECUTIVO-CLIENTE.md` | `PARCIAL` | Mezcla hallazgos reales con conclusiones demasiado fuertes sobre madurez y escalabilidad. | Referenciado desde este informe. |
| `02-ESTADO-REAL-DEL-PROYECTO.md` | `PARCIAL` | Varias etiquetas `OPERATIVO` son optimistas dado el estado de build. | Referenciado desde este informe. |
| `03-INVENTARIO-FUNCIONAL.md` | `PARCIAL` | Contiene piezas reales, pero exagera la ejecucion efectiva de cron jobs. | Referenciado desde este informe. |
| `04-ARQUITECTURA-ACTUAL.md` | `PARCIAL` | Acierta en modularidad, pero sobregeneraliza con "sistemas distribuidos" y "cada modulo es dueno de su base". | Referenciado desde este informe. |
| `05-DIAGRAMAS-ARQUITECTURA.md` | `PARCIAL` | Sirve como intencion arquitectonica, no como fotografia operativa exacta. | Referenciado desde este informe. |
| `06-DECISIONES-TECNICAS.md` | `PARCIAL` | La logica es razonable, pero algunas consecuencias empresariales estan sobreprometidas. | Referenciado desde este informe. |
| `07` a `13` | `PARCIAL` | No se detectaron contradicciones tan graves como en otros docs, pero deben leerse junto a este informe. | Sin cambio directo. |
| `14-INTEGRACIONES.md` | `PARCIAL` | La integracion existe, pero el recovery y CAPI no deben venderse como blindaje completo. | Referenciado desde este informe. |
| `15-INFRAESTRUCTURA-Y-DEPLOY.md` | `PARCIAL/INCORRECTO` | Menciona herramientas no usadas y sobreafirma readiness. | Corregido. |
| `16-CONTINUIDAD-OPERACIONAL.md` | `INCORRECTO` | Afirmaba mitigacion total por recovery job sin demostrar ejecucion real. | Corregido. |
| `17` a `24` | `PARCIAL` | Utiles como marco, pero no como evidencia absoluta. | Sin cambio directo. |
| `25-PRIVACIDAD-Y-CUMPLIMIENTO.md` | `INCORRECTO` | Hacia afirmaciones legales absolutas que el codigo no permite certificar. | Corregido. |
| `26-PENDIENTES-Y-ROADMAP.md` | `PARCIAL` | Alineado como intencion, no como prueba. | Sin cambio directo. |
| `27-MATRIZ-DE-VERACIDAD.md` | `PARCIAL/INCORRECTO` | Faltaban hallazgos de build, jobs y Drive. | Corregido. |
| `28-MATRIZ-DE-RIESGOS.md` | `PARCIAL` | Algunos residuales estaban subestimados. | Referenciado desde este informe. |
| `29-MATRIZ-DE-EVIDENCIAS.md` | `INCORRECTO/PARCIAL` | Varias evidencias no correspondian exactamente a lo que afirmaban. | Corregido. |
| `30-MANUAL-TECNICO.md` | `INCORRECTO/PARCIAL` | Menciona `pnpm`, `yarn` y practicas no verificadas como estandar real actual. | Referenciado desde este informe. |
| `31-MANUAL-DE-DESPLIEGUE.md` | `PARCIAL` | Util como guia, pero no como procedimiento completamente validado. | Referenciado desde este informe. |
| `32-MANUAL-DE-CONTINUIDAD.md` | `INCORRECTO` | Sobrepromete recuperacion impecable por recovery job. | Referenciado desde este informe y cubierto por 16. |
| `33-INFORME-FINAL-PARA-CLIENTE.md` | `INCORRECTO/PARCIAL` | Usaba lenguaje absoluto incompatible con el estado real del workspace. | Corregido. |
| `34-ESPECIFICACION-DE-APIS.md` | `PARCIAL/INCORRECTO` | Mezclaba endpoints reales con detalles no garantizados. | Corregido. |

## 6. Evidencia concreta clave

### 6.1 Tests y calidad

- `apps/api/test/**` contiene cobertura real en auth, tenancy, jobs, integraciones, produccion y mas.
- `npm run test:api` paso el `2026-07-16`.

### 6.2 Fallas de integracion actuales

- `apps/api/src/core/jobs/cron/meta-lead-recovery.job.ts`
  Ruta de imports incorrecta.
- `apps/api/src/modules/integrations/meta/handlers/lead-converted.handler.ts`
  Uso de `IntegrationAccountType.PIXEL` no presente en el enum actual.
- `apps/web/src/features/crm/components/LeadDetailDrawer.tsx`
  Imports relativos incorrectos.

### 6.3 Integraciones y secretos

- `apps/api/src/modules/integrations/meta/meta.controller.ts`
  Webhook publico, verificacion y data deletion.
- `apps/api/src/modules/integrations/meta/meta-lead-ads.service.ts`
  Descarga y normalizacion de leads.
- `apps/api/src/shared/security/integration-secrets.ts`
  Cifrado AES-256-GCM de secretos.

### 6.4 Jobs

- `apps/api/src/core/jobs/jobs.module.ts`
  Registro de providers de jobs.
- `infrastructure/cron/crontab`
  Intento de orquestacion externa, pero debe revalidarse porque las rutas apuntadas no coinciden claramente con la salida compilada esperable.

## 7. Recomendaciones prioritarias

1. Corregir primero el estado de build del backend y frontend.
2. Decidir una estrategia unica y verificable para ejecucion de jobs.
3. Corregir el flujo CAPI para que compile y pueda auditarse de punta a punta.
4. No prometer mitigacion total de continuidad ni cumplimiento legal total hasta tener despliegue, monitoreo, backups y procedimientos probados.
5. Tratar Google Drive como integracion futura o parcial hasta implementar `syncToDrive()`.

## 8. Conclusion operativa

La mejor descripcion defendible del proyecto al `2026-07-16` es:

- base amplia y seria;
- varios modulos reales y no triviales;
- buena senal de calidad por cobertura de pruebas en API;
- estado todavia incompleto para declararlo plenamente operativo o listo para produccion sin reservas.

Este documento pasa a ser la referencia principal de veracidad del paquete `docs/auditoria-entrega`.
