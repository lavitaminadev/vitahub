# 32. Manual de Continuidad y Desastres (Playbook)

Instrucciones exactas a seguir ante los incidentes más críticos.

### Evento 1: Fuga o Exposición de Tokens CAPI (Meta)
**Síntoma:** Alguien subió por accidente el `.env` a GitHub o se vulneró el servidor.
**Respuesta Inmediata:**
1. Ir al Panel de Desarrolladores de Facebook.
2. Ingresar a "Configuración" > "Básica" y presionar "Restablecer clave secreta de la aplicación" (Reset App Secret).
3. Entrar a las variables de entorno del servidor VPS (Ej: Panel de Render).
4. Reemplazar la variable `META_APP_SECRET` antigua por la nueva.
5. Reiniciar el servicio backend. Todos los hackers quedarán bloqueados instantáneamente de inyectar leads.

### Evento 2: Fallo Catastrófico de Base de Datos
**Síntoma:** Se borró una tabla entera o un "DBA" hizo `DROP DATABASE`.
**Respuesta Inmediata:**
1. Detener el servidor backend apagando el contenedor para evitar que los Webhooks de Meta se rechacen y nos baneen el sistema. (Si el servidor de Meta ve que nuestro servidor no funciona por 8 horas, simplemente pone los Leads en pausa, lo cual nos da tiempo a nosotros).
2. Abrir el panel de respaldos diarios de la base de datos (Ej: Amazon RDS Snapshots / Render Database Backups).
3. Seleccionar "Restore to Point-in-Time" hacia las 2:00 AM de esa misma mañana.
4. Levantar el Backend. 
5. El servidor revivirá en la mañana. Al iniciar, el `MetaLeadRecoveryJob` detectará que le faltan los prospectos que entraron entre las 2:00 AM y la hora del desastre, y llamará a Facebook para inyectarlos retroactivamente y curar el tiempo perdido de manera impecable.
