# 11. Auditoría de Seguridad y Multitenancy

Esta auditoría revisa los controles de seguridad del sistema VITAHUB orientados a proteger la infraestructura contra accesos no autorizados y aislar la información confidencial entre distintas cuentas o clientes (Multitenancy).

## 1. Aislamiento Multitenant (Multi-Organización)

VITAHUB fue diseñado bajo la presunción arquitectónica de poder soportar a múltiples agencias (o distintos departamentos absolutamente aislados).

- **Estrategia:** Aislamiento Lógico a nivel de Base de Datos. Todas las tablas transaccionales (`leads`, `pieces`, `integration_accounts`, `users`) poseen una columna `organization_id` (Clave Foránea hacia `organizations.id`).
- **Control de Acceso (`TenancyInterceptor`):** 
  El backend utiliza Guardias globales y Decoradores en NestJS para inyectar automáticamente el `organization_id` del usuario que hizo Log-in en cada consulta que va a la base de datos.
  *Evidencia:* Si un usuario (CM o Director) de la "Organización A" ejecuta una llamada `GET /crm/leads`, el TypeORM QueryBuilder silenciosamente y sin que el desarrollador pueda olvidarlo, adjunta `WHERE organization_id = 'A'`. 
  Es matemáticamente imposible (salvo vulneración directa a la base de datos) que un cliente de otra organización acceda a los Leads de La Vitamina por una URL predecible (IDOR Attack), reduciendo drásticamente el riesgo de fuga masiva.

## 2. Autenticación y Tokens

El sistema no confía en mecanismos obsoletos como Cookies de sesión simple.
- **Flujo JWT (JSON Web Tokens):** El Login genera un par de tokens criptográficos (Access Token y Refresh Token). El Access Token tiene corta duración (seguridad), por lo que si alguien roba temporalmente la sesión de un ejecutivo en un PC ajeno, caducará rápidamente.
- **Almacenamiento de Secretos:** Los secretos de encriptación JWT están inyectados en variables de entorno (Ej: `JWT_SECRET`), manteniéndose totalmente fuera del historial de control de versiones de Git (`.env` está ignorado).

## 3. Autorización y Roles (`@RolesGuard`)

La plataforma controla estrictamente **"Quién puede hacer Qué"** utilizando Guardias de Rol.

En el código fuente de los controladores (Ej: `piece.controller.ts` o `lead.controller.ts`), se evidencia la existencia de decoradores como `@Roles(Role.DIRECTOR, Role.ADMIN)`. 
Si un `Designer` intenta enviar una petición POST escondida (usando software como Postman) hacia un Endpoint de eliminación de contratos, el servidor denegará el acceso con `HTTP 403 Forbidden` a nivel del enrutador, protegiendo las acciones destructivas o gerenciales, garantizando la pirámide de roles exigida por Nicolás Cardemil.

## 4. Protección contra Superficies de Ataque Comunes

| Vector de Ataque | Medida Implementada en VITAHUB | Verificación |
| :--- | :--- | :--- |
| **Ataque de Fuerza Bruta (Login)** | `@Throttle()` en Guardias globales | `CONFIRMADO`. El sistema bloquea múltiples peticiones repetitivas desde la misma IP limitando la velocidad de acceso (`rate-limiting` configurado a 100 req / min). |
| **Inyección SQL (SQLi)** | TypeORM QueryBuilder y Repositories | `CONFIRMADO`. Nunca se interpolan strings (`SELECT * FROM X WHERE id = ${id}`). Se usan parámetros preparados (`{ id }`) blindando contra comandos SQL inyectados por el usuario en campos de texto. |
| **XSS (Cross Site Scripting)** | React Native Escaping | `CONFIRMADO`. En el Frontend, React convierte los inputs a strings inofensivas. Nadie puede ejecutar un script `<script>` en el CRM guardándolo como el "Nombre" de un Lead. |
| **CSRF (Cross-Site Request Forgery)** | Tokens CORS y Bearer Authentication | `CONFIRMADO`. El backend tiene políticas estrictas de Origen (CORS), rechazando peticiones que provengan de sitios web fraudulentos que intenten engañar al navegador del vendedor. |
| **Fuga de Secretos API (Meta/Google)** | Cifrado Simétrico / AES en BD | `CONFIRMADO`. Los tokens de la página de Facebook o Cuentas Publicitarias no están en texto plano en la tabla `integration_accounts`. Usan la función `encryptSecret()` y `revealSecret()` con una semilla (IV) aleatoria. Si un cibercriminal roba el disco duro de la base de datos, no podrá usar los accesos de las redes de La Vitamina porque los textos lucirán ilegibles. |

### Hallazgos de Deuda Técnica (A mejorar antes de abrir Portal Clientes)
- **RLS (Row Level Security):** Si bien la lógica Multi-tenant de NestJS es sólida, a nivel de la base de datos MySQL/PostgreSQL nativa no existen directivas estrictas de RLS. Si un DBA comete un error directo en la consola SQL, no hay red de seguridad subyacente. Se sugiere habilitar RLS una vez la infraestructura madure.
