# 23. Costos y Dependencias (SaaS y API)

El objetivo central de VITAHUB ha sido reducir drásticamente los gastos variables recurrentes de "La Vitamina". Sin embargo, ciertas integraciones mantienen costos fijos de servidores o por uso.

| Servicio | Función | Necesidad | Vendor Lock-in | Costo Futuro Posible |
| :--- | :--- | :--- | :--- | :--- |
| **Meta Graph API** | Conexión Webhook Leads/CAPI | Obligatoria (Core) | Absoluto (Solo existe Meta) | Gratuito (Hasta límites exorbitantes) |
| **Hosting (Ej: Render / AWS)** | Servidor de NestJS / React | Crítica | Muy Bajo (Se despliega en Docker) | 20 a 50 USD / mes (según RAM base de datos) |
| **Facturación (Ej: Toku/Bsale)**| Emisión DTE Automática | Crítica | Alto | Costo FIJO según plan del proveedor chileno (Aprox 2UF/Mes) |
| **SaaS CRM Tradicional (Pipedrive)**| **[EVITADO]** | Reemplazado por VITAHUB | Alto | Ahorro inmediato de >100 USD mensuales por volumen de agentes. |
