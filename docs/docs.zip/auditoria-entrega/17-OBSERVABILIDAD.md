# 17. Observabilidad (Logs y Alertas)

La observabilidad es la capacidad de "ver qué pasa dentro del servidor" sin tener que detenerlo.

## Logs Estructurados
- **Estado Actual:** `PARCIAL`. NestJS provee por defecto un `Logger` incorporado. Cuando ocurren errores en la conversión de clientes o fallos en los Webhooks de Meta, el error se imprime en la consola del servidor de forma básica.
- **Problema:** En servidores efímeros, la consola se borra. Si ocurre un error a las 3:00 AM, el desarrollador no sabrá por qué Meta cortó la conexión.

## Recomendaciones Inmediatas (Paso a Producción)
1. **Integración con Sentry:** La plataforma necesita capturar "Exceptions" de forma estructurada. Se debe instalar un interceptor de Error Tracking (como Sentry o Datadog) para que envíe un correo instantáneo al equipo técnico si la base de datos rechaza una conexión o falla la inserción de un prospecto crítico.
2. **Tablas de Auditoría (Audit Trails):** Para cumplir con las reglas del Documento Maestro ("Trazabilidad Completa: quién hizo qué y cuándo"), se debe escalar la capa de TypeORM para utilizar *Subscribers* (Observadores de Eventos) que guarden en una tabla especial cada modificación de estado que los vendedores hacen a una pieza o prospecto, registrando el ID del empleado y la fecha.
