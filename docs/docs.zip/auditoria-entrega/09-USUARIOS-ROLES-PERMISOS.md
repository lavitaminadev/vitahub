# 09. Usuarios, Roles y Permisos

La plataforma cuenta con un sistema robusto de permisos (RBAC - Role Based Access Control) inyectado mediante NestJS Guards (`@RolesGuard`). 

## Matriz de Acceso Encontrada (Implementación Real)

| Acción / Módulo | ADMIN | DIRECTOR | CM / CUENTAS | DISEÑADOR | CLIENTE |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Ver todos los Leads** | ✅ Sí | ✅ Sí | ❌ No (Sólo los propios/su Pod) | ❌ No | ❌ No |
| **Convertir Lead a Cliente** | ✅ Sí | ✅ Sí | ✅ Sí (Si está asignado) | ❌ No | ❌ No |
| **Modificar Planes / UDs** | ✅ Sí | ✅ Sí | ❌ No | ❌ No | ❌ No |
| **Aprobar Pieza Internamente** | ✅ Sí | ✅ Sí | ✅ Sí (Como filtro previo) | ❌ No | ❌ No |
| **Aprobar Pieza (Final)** | ❌ N/A | ❌ N/A | ❌ N/A | ❌ N/A | ✅ Sí (Desde Portal Cliente) |
| **Borrar Cuenta de Organización** | ✅ Sí | ❌ No | ❌ No | ❌ No | ❌ No |
| **Ver Puntos XP Globales** | ✅ Sí | ✅ Sí | ❌ No | ❌ No (Solo los propios) | ❌ No |

## Mecanismo de Seguridad Subyacente
- No basta con "esconder" el botón en la interfaz de React.
- Si un usuario modifica el código fuente de su navegador o usa herramientas de hacking, la petición viaja al Backend. 
- En el Backend, el archivo de rutas exige un token firmado (JWT) que contiene el rol criptográficamente inalterable. El Guard evalúa si la ruta permite ese rol; si no, lanza una excepción de seguridad (HTTP 403 Forbidden).
