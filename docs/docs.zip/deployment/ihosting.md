# Deploy en iHosting (cPanel + Phusion Passenger)

## Prerrequisitos
- Node.js 20.20.2 (disponible en iHosting)
- MySQL/MariaDB (crear DB desde cPanel)
- Phusion Passenger habilitado en cPanel
- Git instalado en el servidor

## Instalación

```bash
# 1. Clonar repositorio
cd /home/mbarrios/repositories
git clone https://github.com/lavitaminadev/vitahub.git
cd vitahub

# 2. Instalar dependencias
npm ci

# 3. Configurar variables de entorno
cp .env.example .env
# Editar .env con credenciales reales (DB, JWT, etc.)

# 4. Compilar backend
npm run build --workspace=apps/api

# 5. Compilar frontend
npm run build --workspace=apps/web

# 6. Configurar Passenger en cPanel
# Application root: repositories/vitahub
# Startup file: app.js
# Node version: 20.20.2

# 7. Configurar dominio/sitio web
# Document root: public_html o apuntar a apps/web/dist
# O servir frontend desde Passenger config

# 8. Ejecutar migraciones
npm run migration:run

# 9. Reiniciar app desde cPanel
```

## Estructura de Archivos

```
/home/mbarrios/repositories/vitahub/
├── app.js                          # Passenger startup
├── apps/api/dist/main.js           # Backend compilado
├── apps/web/dist/                  # Frontend compilado
├── .env                            # Variables de entorno
└── package.json
```

## Comandos

| Acción | Comando |
|--------|---------|
| Instalar | `npm ci` |
| Build backend | `npm run build --workspace=apps/api` |
| Build frontend | `npm run build --workspace=apps/web` |
| Tests | `npm run test --workspace=apps/api` |
| Migraciones | `npm run migration:run` |
| Reiniciar | Restart app desde cPanel o `touch app.js` |

## Variables de Entorno (`.env`)

| Variable | Descripción |
|----------|-------------|
| `NODE_ENV` | `production` |
| `PORT` | Puerto del backend (3000) |
| `DATABASE_URL` | `mysql://user:pass@host/db` |
| `JWT_SECRET` | Secreto JWT |
| `JWT_EXPIRES_IN` | `15m` |
| `JWT_REFRESH_EXPIRES_IN` | `7d` |
| `CORS_ORIGIN` | Origen permitido (dominio frontend) |
| `META_APP_ID` | App ID de Meta (opcional) |
| `META_APP_SECRET` | App Secret de Meta (opcional) |

## Notas
- Passenger ejecuta `app.js` con Node 20.20.2
- El build debe regenerarse en cada deploy
- Las migraciones se ejecutan manualmente
- No usar `npm install`, usar `npm ci` para instalaciones limpias
